package com.seroter.unknownPaw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UnknownPawApplication {

	public static void main(String[] args) {
		SpringApplication.run(UnknownPawApplication.class, args);
	}

}
